﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("AwaitableCoroutine.FSharp")]
