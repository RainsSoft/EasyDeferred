﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BenchmarkDotNet-Dev")] // Remove "Dev" for NuGet publishing
[assembly: AssemblyDescription("A lightweight .NET library for benchmarking")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BenchmarkDotNet")]
[assembly: AssemblyCopyright("Copyright © Andrey Akinshin, Jon Skeet, Matt Warren 2013–2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("cbba82d3-e650-407f-a0f0-767891d4f04c")]

[assembly: AssemblyVersion("0.7.8")]
[assembly: AssemblyFileVersion("0.7.8")]
