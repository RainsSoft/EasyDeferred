﻿namespace BenchmarkDotNet.Tasks
{
    public enum BenchmarkJitVersion
    {
        HostJit, LegacyJit, RyuJit
    }
}