﻿namespace BenchmarkDotNet.Tasks
{
    public enum BenchmarkPlatform
    {
        HostPlatform, AnyCpu, X86, X64
    }
}