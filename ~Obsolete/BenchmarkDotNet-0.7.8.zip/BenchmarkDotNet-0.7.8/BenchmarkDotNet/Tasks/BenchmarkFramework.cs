﻿namespace BenchmarkDotNet.Tasks
{
    public enum BenchmarkFramework
    {
        HostFramework, V35, V40, V45, V451, V452, V46
    }
}