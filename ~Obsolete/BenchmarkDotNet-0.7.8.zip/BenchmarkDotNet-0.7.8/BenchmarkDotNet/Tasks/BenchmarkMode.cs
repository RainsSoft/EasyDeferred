﻿namespace BenchmarkDotNet.Tasks
{
    public enum BenchmarkMode
    {
        SingleRun,
        Throughput
    }
}