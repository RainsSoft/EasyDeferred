﻿namespace BenchmarkDotNet.Logging
{
    public enum BenchmarkLogKind
    {
        Default, Help, Header, Result, Statistic, Info, Error
    }
}