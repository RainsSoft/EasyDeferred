﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BenchmarkDotNet.IntegrationTests")]
[assembly: AssemblyDescription("BenchmarkDotNet IntegrationTests")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BenchmarkDotNet.IntegrationTests")]
[assembly: AssemblyCopyright("Copyright © Andrey Akinshin 2013-2015, Matt Warren 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("74362bb1-9f64-4be5-b079-b4ac19dae5db")]

[assembly: AssemblyVersion("0.7.7")]
[assembly: AssemblyFileVersion("0.7.7")]
