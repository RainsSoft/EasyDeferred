﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BenchmarkDotNet.Samples")]
[assembly: AssemblyDescription("BenchmarkDotNet Samples")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BenchmarkDotNet.Samples")]
[assembly: AssemblyCopyright("Copyright © Andrey Akinshin, Jon Skeet, Matt Warren 2013–2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("6f2232a9-0d0c-46cf-b08c-f6e28ab612e3")]

[assembly: AssemblyVersion("0.7.8")]
[assembly: AssemblyFileVersion("0.7.8")]