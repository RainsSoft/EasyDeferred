﻿// <copyright file="AssemblyInfo.cs" company="Nito Programs">
//     Copyright (c) 2009 Nito Programs.
// </copyright>

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Helper classes for asynchronous programming")]
[assembly: AssemblyCompany("Nito Programs")]
[assembly: AssemblyProduct("Nito Libraries")]
[assembly: AssemblyCopyright("Copyright © Nito Programs 2009")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("1.4.0.0")]

